import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Router } from '@angular/router';
import { addIcons } from 'ionicons';
import { personOutline, lockClosedOutline, logInOutline } from 'ionicons/icons';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule],
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {

  cedula = '';
  password = '';
  mostrarPassword = false;

  cargando = signal(false);
  errorMensaje = signal<string | null>(null);

  constructor(
    private authService: AuthService,
    private router: Router
  ) {
    addIcons({ personOutline, lockClosedOutline, logInOutline });
  }

  async onSubmit() {

    console.log('🚀 LOGIN INICIADO');

    if (!this.cedula || !this.password) {
      this.errorMensaje.set('Ingresa cédula y contraseña');
      return;
    }

    this.cargando.set(true);

    this.authService.login({
      cedula: this.cedula.trim(),
      password: this.password
    }).subscribe({
      next: async (res) => {

        console.log('✅ RESPONSE:', res);

        try {
          // 1. guardar sesión ANTES de navegar
          await this.authService.setSession(res.usuario, res.token);

          console.log('💾 sesión guardada');

          // 2. usar usuario del RESPONSE (NO SIGNAL)
          const ruta = this.authService.rutaInicioSegunRol();
          console.log('➡️ navegando a:', ruta);

          await this.router.navigateByUrl(ruta);

        } catch (e) {
          console.error('ERROR EN LOGIN FLOW:', e);
        }

        this.cargando.set(false);
      },

      error: (err) => {
        console.log('❌ ERROR LOGIN:', err);

        this.errorMensaje.set(
          err?.error?.mensaje || 'Error al iniciar sesión'
        );

        this.cargando.set(false);
      }
    });
  }
}